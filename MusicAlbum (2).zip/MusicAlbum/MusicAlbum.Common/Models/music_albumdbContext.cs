﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MusicAlbum.Common.Models
{
    public partial class music_albumdbContext : DbContext
    {
        public music_albumdbContext()
        {
        }

        public music_albumdbContext(DbContextOptions<music_albumdbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AlbumtypeMaster> AlbumtypeMaster { get; set; }
        public virtual DbSet<ArtistMaster> ArtistMaster { get; set; }
        public virtual DbSet<GenreMaster> GenreMaster { get; set; }
        public virtual DbSet<MusicMaster> MusicMaster { get; set; }
        public virtual DbSet<TitleMaster> TitleMaster { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySQL("Server=127.0.0.1;port=3306;Database=music_albumdb;Uid=root;Pwd=Mysql@123");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AlbumtypeMaster>(entity =>
            {
                entity.HasKey(e => e.AlbumId)
                    .HasName("PRIMARY");

                entity.ToTable("albumtype_master");

                entity.HasIndex(e => e.GenreId)
                    .HasName("genre_id");

                entity.Property(e => e.AlbumId).HasColumnName("album_id");

                entity.Property(e => e.AlbumName)
                    .HasColumnName("album_name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GenreId).HasColumnName("genre_id");

                entity.Property(e => e.Year).HasColumnName("year");

                entity.HasOne(d => d.Genre)
                    .WithMany(p => p.AlbumtypeMaster)
                    .HasForeignKey(d => d.GenreId)
                    .HasConstraintName("albumtype_master_ibfk_1");
            });

            modelBuilder.Entity<ArtistMaster>(entity =>
            {
                entity.HasKey(e => e.ArtistId)
                    .HasName("PRIMARY");

                entity.ToTable("artist_master");

                entity.HasIndex(e => e.TitleId)
                    .HasName("title_id");

                entity.Property(e => e.ArtistId).HasColumnName("artist_id");

                entity.Property(e => e.ArtistName)
                    .HasColumnName("artist_name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MusicdirectorName)
                    .HasColumnName("musicdirector_name")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Profession)
                    .HasColumnName("profession")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TitleId).HasColumnName("title_id");

                entity.HasOne(d => d.Title)
                    .WithMany(p => p.ArtistMaster)
                    .HasForeignKey(d => d.TitleId)
                    .HasConstraintName("artist_master_ibfk_1");
            });

            modelBuilder.Entity<GenreMaster>(entity =>
            {
                entity.HasKey(e => e.GenreId)
                    .HasName("PRIMARY");

                entity.ToTable("genre_master");

                entity.Property(e => e.GenreId).HasColumnName("genre_id");

                entity.Property(e => e.GenereName)
                    .HasColumnName("genere_name")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<MusicMaster>(entity =>
            {
                entity.HasKey(e => e.MusicId)
                    .HasName("PRIMARY");

                entity.ToTable("music_master");

                entity.HasIndex(e => e.AlbumId)
                    .HasName("album_id");

                entity.HasIndex(e => e.ArtistId)
                    .HasName("artist_id");

                entity.HasIndex(e => e.GenreId)
                    .HasName("genre_id");

                entity.HasIndex(e => e.TitleId)
                    .HasName("title_id");

                entity.Property(e => e.MusicId).HasColumnName("music_id");

                entity.Property(e => e.AlbumId).HasColumnName("album_id");

                entity.Property(e => e.ArtistId).HasColumnName("artist_id");

                entity.Property(e => e.GenreId).HasColumnName("genre_id");

                entity.Property(e => e.TitleId).HasColumnName("title_id");

                entity.HasOne(d => d.Album)
                    .WithMany(p => p.MusicMaster)
                    .HasForeignKey(d => d.AlbumId)
                    .HasConstraintName("music_master_ibfk_1");

                entity.HasOne(d => d.Artist)
                    .WithMany(p => p.MusicMaster)
                    .HasForeignKey(d => d.ArtistId)
                    .HasConstraintName("music_master_ibfk_3");

                entity.HasOne(d => d.Genre)
                    .WithMany(p => p.MusicMaster)
                    .HasForeignKey(d => d.GenreId)
                    .HasConstraintName("music_master_ibfk_4");

                entity.HasOne(d => d.Title)
                    .WithMany(p => p.MusicMaster)
                    .HasForeignKey(d => d.TitleId)
                    .HasConstraintName("music_master_ibfk_2");
            });

            modelBuilder.Entity<TitleMaster>(entity =>
            {
                entity.HasKey(e => e.TitleId)
                    .HasName("PRIMARY");

                entity.ToTable("title_master");

                entity.HasIndex(e => e.AlbumId)
                    .HasName("album_id");

                entity.Property(e => e.TitleId).HasColumnName("title_id");

                entity.Property(e => e.AlbumId).HasColumnName("album_id");

                entity.Property(e => e.TitleName)
                    .HasColumnName("title_name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.Album)
                    .WithMany(p => p.TitleMaster)
                    .HasForeignKey(d => d.AlbumId)
                    .HasConstraintName("title_master_ibfk_1");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
