﻿namespace MusicAlbum.Common.Models
{
    public class MusicDetailsViewModel
    {
        public string GenereName { get; set; }
        public string AlbumName { get; set; }
        public string TitleName { get; set; }
        public string ArtistName { get; set; }     
        public string MusicdirectorName { get; set; }
    }
}
