﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;

namespace MusicAlbum.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenreMasterController : ControllerBase
    {
        private readonly IGenreMasterContext _genreMasterContext;
        private readonly IConfiguration _configuration;
        public GenreMasterController(IGenreMasterContext genreMasterContext, IConfiguration configuration)
        {
            _genreMasterContext = genreMasterContext;
            _configuration = configuration;
        }
        [HttpPost("AddGenre")]
        public IActionResult AddGenre(GenreMaster genreMaster)
        {
            var resp = _genreMasterContext.AddGenre(genreMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Genre added successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }
        [HttpGet("GetAllGenre")]
        public IActionResult GetAllGenre()
        {
            var result = _genreMasterContext.GetAllGenre();
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }
        }
        [HttpGet("GetGenreById")]
        public IActionResult GetGenreById(GenreMaster genreMaster)
        {
            var result = _genreMasterContext.GetGenreById(genreMaster);
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }

        }

        [HttpPost("UpdateGenre")]
        public IActionResult UpdateGenre(GenreMaster genreMaster)
        {
            var resp = _genreMasterContext.UpdateGenre(genreMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Genre Updated successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }
        [HttpGet("DeleteGenre")]
        public IActionResult DeleteGenre(GenreMaster genreMaster)
        {
            var resp = _genreMasterContext.DeleteGenre(genreMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Genre Deleted successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Not found" });
                return response;
            }
        }
    }
}