﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;

namespace MusicAlbum.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MusicAlbumController : ControllerBase
    {
        private readonly IAlbumsContext _albumsContext;
        private readonly IConfiguration _configuration;
        public MusicAlbumController(IAlbumsContext albumsContext, IConfiguration configuration)
        {
            _albumsContext = albumsContext;
            _configuration = configuration;
        }
        [HttpPost("AddAlbum")]
        public IActionResult AddAlbum(AlbumtypeMaster albumtypeMaster)
        {
            var resp = _albumsContext.AddAlbums(albumtypeMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Album added successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }
        [HttpGet("GetAllAlbums")]
        public IActionResult GetAllAlbums()
        {
            var result = _albumsContext.GetAllAlbums();
            if (result != null)
            {
                var response = Ok(new {  Albums = result });
                return response;
            }
            else
            {
                var response = Ok(new {  ErrorMessage = "not found" });
                return response;
            }
        }
        [HttpGet("GetAlbumById")]
        public IActionResult GetAlbumById(int genreid)
        {
            var result = _albumsContext.GetAlbumById(genreid);
            if (result != null)
            {
                var response = Ok(new { Album = result });
                return response;
            }
            else
            {
                var response = Ok(new { ErrorMessage = "not found" });
                return response;
            }
           
        }

        [HttpPost("UpdateAlbum")]
        public IActionResult UpdateAlbum(AlbumtypeMaster albumtypeMaster)
        {
            var resp = _albumsContext.UpdateAlbum(albumtypeMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Album Updated successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }
        [HttpGet("DeleteAlbum")]
        public IActionResult DeleteAlbum(AlbumtypeMaster albumtypeMaster)
        {
            var resp = _albumsContext.DeleteAlbum(albumtypeMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Album Deleted successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Not found" });
                return response;
            }
        }
    }
}