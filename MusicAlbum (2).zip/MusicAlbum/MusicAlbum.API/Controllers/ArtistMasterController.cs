﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;

namespace MusicAlbum.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistMasterController : ControllerBase
    {
        private readonly IArtistMasterContext _artistMasterContext;               
        private readonly IConfiguration _configuration;

        public ArtistMasterController(IArtistMasterContext artistMasterContext, IConfiguration configuration)
        {
            _artistMasterContext = artistMasterContext;
            _configuration = configuration;
        }

        [HttpPost("AddArtist")]
        public IActionResult AddArtist(ArtistMaster artistMaster)
        {
            var resp = _artistMasterContext.AddArtist(artistMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Artist added successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }
     
        [HttpGet("GetAllArtists")]
        public IActionResult GetAllArtists()
        {           
            var result = _artistMasterContext.GetAllArtists();
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }
        }
        
        
        [HttpGet("GetArtistById")]
        public IActionResult GetArtistById(int titleid)
        {                                                           
            var result = _artistMasterContext.GetArtistById(titleid);
            if (result != null)
            {
                var response = Ok(new { status = 200, success = true, data = result });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "not found" });
                return response;
            }

        }

        [HttpPost("UpdateArtist")]
        public IActionResult UpdUpdateArtistateAlbum(ArtistMaster artistMaster)
        {
            var resp = _artistMasterContext.UpdateArtist(artistMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Artist Updated successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Please fill the details" });
                return response;
            }
        }
        [HttpGet("DeleteArtist")]
        public IActionResult DeleteArtist(ArtistMaster artistMaster)
        {
            var resp = _artistMasterContext.DeleteArtist(artistMaster);
            if (resp != null)
            {
                var response = Ok(new { status = 200, success = true, data = "Artist Deleted successfully" });
                return response;
            }
            else
            {
                var response = Ok(new { status = 401, success = false, data = "Not found" });
                return response;
            }
        }
    }
}