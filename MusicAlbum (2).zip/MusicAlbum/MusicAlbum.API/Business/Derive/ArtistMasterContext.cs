﻿using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using MusicAlbum.Data.Service.Derive;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Derive
{
    public class ArtistMasterContext : IArtistMasterContext
    {

        private readonly IArtistMasterService _artistMaster;
        public ArtistMasterContext(IArtistMasterService artistMaster)
        {
            _artistMaster = artistMaster;
        }
        public ArtistMaster AddArtist(ArtistMaster artistMaster)
        {
            return _artistMaster.AddArtist(artistMaster);
        }

        public ArtistMaster DeleteArtist(ArtistMaster artistMaster)
        {
            return _artistMaster.DeleteArtist(artistMaster);
        }

        public ArtistMaster GetArtistById(int titleid)
        {
            return _artistMaster.GetArtistById(titleid);
        }

        public List<ArtistMaster> GetAllArtists()
        {
            return _artistMaster.GetAllArtists();
        }

        public ArtistMaster UpdateArtist(ArtistMaster artistMaster)
        {
            return _artistMaster.UpdateArtist(artistMaster);
        }
    }
}
