﻿using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Derive
{
    public class GenreMasterContext : IGenreMasterContext
    {
        private readonly IGenreMasterService _genreMasterService;
        public GenreMasterContext(IGenreMasterService genreMasterService)
        {
            _genreMasterService = genreMasterService;
        }
        public GenreMaster AddGenre(GenreMaster genreMaster)
        {
            return _genreMasterService.AddGenre(genreMaster);
        }

        public GenreMaster DeleteGenre(GenreMaster genreMaster)
        {
            return _genreMasterService.DeleteGenre(genreMaster);
        }

        public List<GenreMaster> GetAllGenre()
        {
            return _genreMasterService.GetAllGenre();
        }

        public GenreMaster GetGenreById(GenreMaster genreMaster)
        {
            return _genreMasterService.GetGenreById(genreMaster);
        }

        public GenreMaster UpdateGenre(GenreMaster genreMaster)
        {
            return _genreMasterService.UpdateGenre(genreMaster);
        }
    }
}
