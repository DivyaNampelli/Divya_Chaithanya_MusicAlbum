﻿using MusicAlbum.API.Business.Abstract;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Derive
{
    public class AlbumsContext : IAlbumsContext
    {
        private readonly IAlbumsService _albumsService;
        public AlbumsContext(IAlbumsService albumsService)
        {
            _albumsService = albumsService;
        }
        public AlbumtypeMaster AddAlbums(AlbumtypeMaster albumtypeMaster)
        {
            return _albumsService.AddAlbums(albumtypeMaster);
        }

        public AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumtypeMaster)
        {
            return _albumsService.DeleteAlbum(albumtypeMaster);
        }

        public List<AlbumtypeMaster> GetAlbumById(int genreid)
        {
            return _albumsService.GetAlbumById(genreid);
        }

        public List<string> GetAllAlbums()
        {
            return _albumsService.GetAllAlbums();
        }

        public AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumtypeMaster)
        {
            return _albumsService.UpdateAlbum(albumtypeMaster);
        }
    }
}
