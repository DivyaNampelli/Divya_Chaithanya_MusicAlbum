﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Abstract
{
    public interface IAlbumsContext
    {
        AlbumtypeMaster AddAlbums(AlbumtypeMaster albumtypeMaster);
        AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumtypeMaster);
        List<string> GetAllAlbums();
        List<AlbumtypeMaster> GetAlbumById(int genreid);
        AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumtypeMaster);
    }
}
