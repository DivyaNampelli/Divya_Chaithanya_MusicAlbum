﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Abstract
{
   public interface IMusicMasterContext
    {
        MusicMaster AddMusic(MusicMaster musicMaster);
        List<MusicMaster> GetAllMusics();
        MusicMaster GetMusicById(MusicMaster musicMaster);
        MusicMaster UpdateMusic(MusicMaster musicMaster);
        MusicMaster DeleteMusic(MusicMaster musicMaster);
        Object GetMusic(MusicDetailsViewModel m);
    }
}
