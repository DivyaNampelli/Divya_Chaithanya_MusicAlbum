﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MusicAlbum.API.Business.Abstract
{
   public interface IArtistMasterContext
    {        
        List<ArtistMaster> GetAllArtists();
        ArtistMaster GetArtistById(int titleid);
        ArtistMaster UpdateArtist(ArtistMaster artistMaster);
        ArtistMaster DeleteArtist(ArtistMaster artistMaster);
        ArtistMaster AddArtist(ArtistMaster artistMaster);
    }
}
