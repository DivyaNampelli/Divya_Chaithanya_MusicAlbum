﻿using MusicAlbum.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MusicAlbum.Data.Service.Abstract
{
   public interface IAlbumsService
    {
        AlbumtypeMaster AddAlbums(AlbumtypeMaster albumtypeMaster);
        List<string> GetAllAlbums();
        List<AlbumtypeMaster> GetAlbumById(int genreid);
        AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumtypeMaster);
        AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumtypeMaster);
    }
}
