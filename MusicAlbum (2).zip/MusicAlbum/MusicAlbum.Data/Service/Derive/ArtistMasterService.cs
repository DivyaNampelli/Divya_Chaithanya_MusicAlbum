﻿using Microsoft.EntityFrameworkCore;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MusicAlbum.Data.Service.Derive
{
    public class ArtistMasterService : IArtistMasterService
    {
        music_albumdbContext _music_AlbumdbContext = new music_albumdbContext();

        public ArtistMaster AddArtist(ArtistMaster artistMaster)
        {
            try
            {
                _music_AlbumdbContext.ArtistMaster.Add(artistMaster);
                _music_AlbumdbContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {

            }
            return artistMaster;
        }

        public ArtistMaster DeleteArtist(ArtistMaster artistMaster)
        {

            var data = _music_AlbumdbContext.ArtistMaster.Where(x => x.ArtistId == artistMaster.ArtistId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.Entry(data).State = EntityState.Deleted;
                    _music_AlbumdbContext.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public ArtistMaster GetArtistById(int titleid)
        {

            var data = _music_AlbumdbContext.ArtistMaster.Where(x => x.TitleId == titleid).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.ArtistMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public List<ArtistMaster> GetAllArtists()
        {
            List<ArtistMaster> artistMasters = _music_AlbumdbContext.ArtistMaster.ToList();
            return artistMasters;
        }

        public ArtistMaster UpdateArtist(ArtistMaster artistMaster)
        {

            ArtistMaster data = _music_AlbumdbContext.ArtistMaster.Where(x => x.ArtistId == artistMaster.ArtistId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    data.ArtistName = string.IsNullOrEmpty(artistMaster.ArtistName) ? data.ArtistName : artistMaster.ArtistName;
                    data.Profession = string.IsNullOrEmpty(artistMaster.Profession) ? data.Profession : artistMaster.Profession;
                    _music_AlbumdbContext.Entry(data).State = EntityState.Modified;
                    _music_AlbumdbContext.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }
    }
}
