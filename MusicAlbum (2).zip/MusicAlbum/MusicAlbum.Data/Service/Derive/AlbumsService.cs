﻿using Microsoft.EntityFrameworkCore;
using MusicAlbum.Common.Models;
using MusicAlbum.Data.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MusicAlbum.Data.Service.Derive
{
    public class AlbumsService : IAlbumsService
    {
        
        music_albumdbContext _music_AlbumdbContext = new music_albumdbContext();

        //public AlbumsService(music_albumdbContext music_AlbumdbContext)
        //{
        //    _music_AlbumdbContext = music_AlbumdbContext;
        //}
        public AlbumtypeMaster AddAlbums(AlbumtypeMaster albumtypeMaster)
        {
            try
            {
                _music_AlbumdbContext.AlbumtypeMaster.Add(albumtypeMaster);
                _music_AlbumdbContext.SaveChanges();
            }
            catch (DbUpdateException ex)
            {

            }
            return albumtypeMaster;
        }

        public AlbumtypeMaster DeleteAlbum(AlbumtypeMaster albumtypeMaster)
        {
            var data = _music_AlbumdbContext.AlbumtypeMaster.Where(x => x.AlbumId == albumtypeMaster.AlbumId).FirstOrDefault();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.Entry(data).State = EntityState.Deleted;
                    _music_AlbumdbContext.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }

        public List<string> GetAllAlbums()
        {
            List<string> albumtypeMasters = _music_AlbumdbContext.AlbumtypeMaster.Select(x => x.AlbumName).ToList();
            return albumtypeMasters;
        }

        public List<AlbumtypeMaster> GetAlbumById(int genreid)
        {
            var data = _music_AlbumdbContext.AlbumtypeMaster.Where(x => x.GenreId == genreid).ToList();
            try
            {
                if (data != null)
                {
                    _music_AlbumdbContext.AlbumtypeMaster.ToList();
                }
            }
            catch (DbUpdateException ex)
            {
                throw ex;
            }
            return data;
        }

        public AlbumtypeMaster UpdateAlbum(AlbumtypeMaster albumtypeMaster)
        {
            AlbumtypeMaster data = _music_AlbumdbContext.AlbumtypeMaster.Where(x => x.AlbumId == albumtypeMaster.AlbumId).FirstOrDefault();
            try
            {
                if(data!=null)
                {
                    data.AlbumName = string.IsNullOrEmpty(albumtypeMaster.AlbumName) ? data.AlbumName : albumtypeMaster.AlbumName;
                    data.Year = (albumtypeMaster.Year == 0) ? data.Year : albumtypeMaster.Year;
                    _music_AlbumdbContext.Entry(data).State = EntityState.Modified;
                    _music_AlbumdbContext.SaveChanges();
                }
            }
            catch (DbUpdateException ex)
            {

            }
            return data;
        }
    }
}
